var handlers = {
	//"error":require('./error.js'),
	"response":require('./responsehandler.js'),
	//"api_response":require('./apiResponse')
};
 
module.exports = handlers;